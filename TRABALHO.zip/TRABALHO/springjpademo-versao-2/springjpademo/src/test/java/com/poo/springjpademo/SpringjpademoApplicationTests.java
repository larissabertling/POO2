package com.poo.springjpademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringjpademoApplicationTests {

	@Test
	void contextLoads() {
	}

}
