package com.poo.springjpademo;

import com.poo.springjpademo.entity.Disciplina;
import com.poo.springjpademo.entity.Professor;
import com.poo.springjpademo.repository.DisciplinaRepository;
import com.poo.springjpademo.repository.ProfessorRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Sort;


@SpringBootApplication
public class SpringjpademoApplication {

    private static final Logger log = LoggerFactory.getLogger(SpringjpademoApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(SpringjpademoApplication.class, args);
    }

    @Bean
    public CommandLineRunner demo(ProfessorRepository professorRepository, DisciplinaRepository disciplinaRepository, TurmaRepository turmaRepository, SalaRepository salaRepository) {

        return (args) -> {
            Professor leanderson = professorRepository.save(new Professor("Leanderson"));
            Professor paulo = professorRepository.save(new Professor("Paulo"));
            Professor vanessa = professorRepository.save(new Professor("Vanessa"));

            Disciplina poo1 = disciplinaRepository.save(new Disciplina("Poo 1"));
            Disciplina poo2 = disciplinaRepository.save(new Disciplina("Poo 2"));
            Disciplina pce = disciplinaRepository.save(new Disciplina("PCE"));
            Disciplina ia = disciplinaRepository.save(new Disciplina("IA"));
            Disciplina redes = disciplinaRepository.save(new Disciplina("Redes"));

            Turma turma1 = new Turma("Turma 1", "Manhã");
            turma1.setProfessor(leanderson);
            turma1.setDisciplinas(Arrays.asList(poo1, poo2, pce));
            turma1.setSala(salaRepository.save(new Sala("Sala 1")));
            turmaRepository.save(turma1);

            Turma turma2 = new Turma("Turma 2", "Tarde");
            turma2.setProfessor(paulo);
            turma2.setDisciplinas(Arrays.asList(ia, redes));
            turma2.setSala(salaRepository.save(new Sala("Sala 2")));
            turmaRepository.save(turma2);

            log.info("-------------------------------");
            log.info("Professores:");
            professorRepository.findAll().forEach(p -> log.info(p.toString()));

            log.info("-------------------------------");
            log.info("Disciplinas:");
            disciplinaRepository.findAll().forEach(d -> log.info(d.toString()));

            log.info("-------------------------------");
            log.info("Turmas:");
            turmaRepository.findAll().forEach(t -> log.info(t.toString()));
        };
    }
}

