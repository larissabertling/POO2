package com.poo.springjpademo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Entity
public class Turma {
    private String codigo;
    private String professor;
    private String disciplina;
    private String horario;
    private Integer periodo;
    private Integer qtd_aula;
    private Integer qtd_interesse;

    public  Turma(String professor, String disciplina,Integer periodo){
        this.professor = professor;
        this.disciplina = disciplina;
        this.periodo = periodo;
    }

    public String toString(){
        if(this.professor == null) return "Sem aula";
        return "Disciplina : "+this.disciplina+"| Professor: "+this.professor+"| Periodo: "+this.periodo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public String getProfessor() {
        return professor;
    }

    public Integer getPeriodo() {
        return periodo;
    }


}

