import java.sql.*;

public class Main {
    public static void main(String[] args) {
        Aluno a1 = new Aluno(0,"Bruno");
        Aluno a2 = new Aluno(0,"Miguel");
        Aluno a3 = new Aluno(0,"Laura");
        Aluno a4 = new Aluno(0,"Catarina");
        Aluno a5 = new Aluno(0,"Joao");
        AlunoDAO alunoDAO = new AlunoDAO();
        // UUID
        //alunoDAO.criarTabela();
        //alunoDAO.inserir(a1);
        //alunoDAO.inserir(a2);
        //alunoDAO.inserir(a3);
        //alunoDAO.inserir(a4);
        //alunoDAO.inserir(a5);
        for(Aluno a : alunoDAO.obterTodos()){
            System.out.println(a);
        }
        System.out.println("Consulta pelo id 1");
        Aluno id1 = alunoDAO.obterPeloId(1);
        System.out.println(id1);
        System.out.println("Consulta pelo id 10");
        Aluno id10 = alunoDAO.obterPeloId(10);
        System.out.println(id10);
        id1.setNome("Pedro Pascal");
        alunoDAO.atualizar(id1);
        System.out.println("Consulta de todas as pessoas.");
        for(Aluno a : alunoDAO.obterTodos()){
            System.out.println(a);
        }
    }
}

