import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Notas {

    private static Notas instancia;

    // Impede de outras classes criar um objeto do tipo Notas
    private Notas(){
    }

    public synchronized static Notas obterInstancia(){
        if(instancia == null){
            instancia = new Notas();
        }
        return instancia;
    }

    public Connection conexao(){
        Connection c = null;
        try{
            c = DriverManager.getConnection("jdbc:sqlite:meu_banco.sql");
        }catch (SQLException e){
            new RuntimeException("Erro ao conectar no banco de dados.",e);
        }
        return c;
    }

}
