import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AlunoDAO extends BaseDAO{

    private final static String CRIAR_TABELA = """
            create table  IF NOT EXISTS aluno(
                                 id INTEGER PRIMARY KEY
                                ,nome text
                                ,matricula text
                                , turma text);
            """;

    public void criarTabela(){
        try(var con = conexao();
            var stat = con.createStatement()){
            stat.execute(CRIAR_TABELA);
        }catch (SQLException e){
            System.out.println("Erro ao criar tabela.");
            e.printStackTrace();
        }
    }

    public void inserir(Aluno a){
        String inserir = """
                    insert into aluno(nome) values(?);
                    """;
        try(var con = conexao();
            var stat = con.prepareStatement(inserir)){
            stat.setString(1,p.getNome());
            stat.execute();
        }catch (SQLException e){
            System.out.println("Erro ao inserir tabela.");
            e.printStackTrace();
        }
    }

    public void atualizar(Aluno a){
        String sql = """
                    update aluno set nome = ? where id = ?;
                    """;
        try(var con = conexao();
            var stat = con.prepareStatement(sql)){
            stat.setString(1,p.getNome());
            stat.setLong(2,p.getId());
            stat.execute();
        }catch (SQLException e){
            System.out.println("Erro ao atualizar aluno.");
            e.printStackTrace();
        }
    }

    public void deletar(long id){
        String sql = """
                    delete aluno where id = ?;
                    """;
        try(var con = conexao();
            var stat = con.prepareStatement(sql)){
            stat.setLong(1,id);
            stat.execute();
        }catch (SQLException e){
            System.out.println("Erro ao excluir aluno.");
            e.printStackTrace();
        }
    }

    public List<Aluno> obterTodos(){
        List<Aluno> lista = new ArrayList<>();
        String sql = """
                    select id, nome, matricula, turma from aluno;
                    """;
        try(var con = conexao();
            var stat = con.prepareStatement(sql)){
            ResultSet rs = stat.executeQuery();
            // Navege para o proximo registro.
            while(rs.next()){
                Aluno a = new Aluno();
                a.setId(rs.getLong("id"));
                a.setNome(rs.getString("nome"));
                a.setMatricula(rs.getString("matricula"));
                a.setTurma(rs.getString("turma"));
                lista.add(a);
            }
        }catch (SQLException e){
            System.out.println("Erro ao consultar todas os alunos.");
            e.printStackTrace();
        }
        return lista;
    }

    public Aluno obterPeloId(long id){
        Aluno a = null;
        String sql = """
                    select id, nome, matricula, turma from aluno where id = ?;
                    """;
        try(var con = conexao();
            var stat = con.prepareStatement(sql)){
            stat.setLong(1,id);
            ResultSet rs = stat.executeQuery();
            // Navege para o proximo registro.
            if(rs.next()){
                a = new Aluno();
                a.setId(rs.getLong("id"));
                a.setNome(rs.getString("nome"));
                a.setMatricula(rs.getString("matricula"));
                a.setTurma(rs.getString("turma"));
            }
        }catch (SQLException e){
            System.out.println("Erro ao consultar aluno pelo id.");
            e.printStackTrace();
        }
        return a;
    }

}
